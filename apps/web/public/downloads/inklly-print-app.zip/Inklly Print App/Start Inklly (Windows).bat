@echo off
title Inklly Print App
cd /d "%~dp0"
echo.
echo   Inklly Print App 1.0.0
echo   ------------------------------------------------
where node >nul 2>nul
if errorlevel 1 goto installnode
node -e "require('node:sqlite')" >nul 2>nul
if errorlevel 1 goto updatenode
goto run

:installnode
echo   Inklly needs Node.js (free, from nodejs.org). Installing it now...
winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto manualnode
echo.
echo   Node.js is installed. Close this window and double-click
echo   "Start Inklly (Windows)" again.
pause
exit /b 0

:updatenode
echo   Your Node.js is too old for Inklly. Updating it now...
winget upgrade -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
if errorlevel 1 goto manualnode
echo.
echo   Node.js is updated. Close this window and double-click
echo   "Start Inklly (Windows)" again.
pause
exit /b 0

:manualnode
echo.
echo   Could not install Node.js automatically.
echo   Download "Node.js LTS" for Windows from https://nodejs.org, install it,
echo   then double-click "Start Inklly (Windows)" again.
start https://nodejs.org/en/download
pause
exit /b 1

:run
set INKLLY_ENABLE_PHYSICAL_PRINTING=true
set INKLLY_SERVER_URL=https://inklly.onrender.com/api/v1
node inklly-print-app.cjs
echo.
echo   Inklly Print App stopped.
pause
