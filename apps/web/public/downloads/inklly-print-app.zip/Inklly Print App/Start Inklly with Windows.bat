@echo off
rem Adds "Start Inklly (Windows)" to the Startup folder so it opens when you sign in.
cd /d "%~dp0"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Inklly Print App.lnk'); $s.TargetPath='%~dp0Start Inklly (Windows).bat'; $s.WorkingDirectory='%~dp0'; $s.Save()"
echo Inklly will now start automatically when you sign in to Windows.
pause
