// Inklly Print App 1.0.0 — connects this computer's printers to your Inklly shop.
"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// apps/agent/src/index.ts
var index_exports = {};
__export(index_exports, {
  AgentDaemon: () => AgentDaemon,
  ConfigManager: () => ConfigManager,
  LocalOfflineQueue: () => LocalOfflineQueue,
  PrinterDiscoveryService: () => PrinterDiscoveryService,
  SpoolerExecutor: () => SpoolerExecutor,
  downloadTicketDocument: () => downloadTicketDocument
});
module.exports = __toCommonJS(index_exports);

// apps/agent/src/agent-daemon.ts
var http = __toESM(require("node:http"));
var os2 = __toESM(require("node:os"));

// apps/agent/src/config.ts
var fs = __toESM(require("node:fs"));
var path = __toESM(require("node:path"));
var DEFAULT_CONFIG = {
  serverUrl: process.env.INKLLY_SERVER_URL || "https://inklly.onrender.com/api/v1",
  localPort: Number(process.env.INKLLY_AGENT_PORT) || 8765,
  shopId: process.env.INKLLY_SHOP_ID || "",
  pairingCode: process.env.INKLLY_PAIRING_CODE,
  isPaired: false,
  pollIntervalMs: 5e3,
  heartbeatIntervalMs: 15e3,
  offlineQueuePath: path.join(process.cwd(), "data", "agent_queue.db")
};
var ConfigManager = class {
  configPath;
  currentConfig;
  constructor(customPath) {
    this.configPath = customPath || path.join(process.cwd(), "data", "agent-config.json");
    this.currentConfig = this.load();
  }
  get() {
    return { ...this.currentConfig };
  }
  update(updates) {
    const next = { ...this.currentConfig, ...updates };
    next.serverUrl = this.validateServerUrl(next.serverUrl);
    this.currentConfig = next;
    this.save();
    return this.get();
  }
  load() {
    try {
      if (fs.existsSync(this.configPath)) {
        const raw = fs.readFileSync(this.configPath, "utf-8");
        const config = { ...DEFAULT_CONFIG, ...JSON.parse(raw) };
        config.serverUrl = this.validateServerUrl(config.serverUrl);
        if (config.isPaired) config.pairingCode = void 0;
        return config;
      }
    } catch {
    }
    return { ...DEFAULT_CONFIG };
  }
  validateServerUrl(value) {
    let url;
    try {
      url = new URL(value);
    } catch {
      throw new Error("The Inklly server URL is invalid.");
    }
    const localHost = ["localhost", "127.0.0.1", "[::1]"].includes(url.hostname);
    if (url.username || url.password || url.protocol !== "https:" && !(url.protocol === "http:" && localHost)) {
      throw new Error("The Inklly server URL must use HTTPS. HTTP is allowed only for localhost development.");
    }
    return url.toString().replace(/\/$/, "");
  }
  save() {
    try {
      const dir = path.dirname(this.configPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(this.configPath, JSON.stringify(this.currentConfig, null, 2), { encoding: "utf-8", mode: 384 });
      if (process.platform !== "win32") fs.chmodSync(this.configPath, 384);
    } catch (err) {
      console.error("[Agent Config] Failed to save config file:", err);
    }
  }
};

// apps/agent/src/local-queue.ts
var import_node_sqlite = require("node:sqlite");
var fs2 = __toESM(require("node:fs"));
var path2 = __toESM(require("node:path"));
var LocalOfflineQueue = class {
  db;
  constructor(dbPath = ":memory:") {
    if (dbPath !== ":memory:") {
      const dir = path2.dirname(dbPath);
      if (!fs2.existsSync(dir)) {
        fs2.mkdirSync(dir, { recursive: true });
      }
    }
    this.db = new import_node_sqlite.DatabaseSync(dbPath);
    this.initSchema();
  }
  initSchema() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS local_commands (
        command_id TEXT PRIMARY KEY,
        job_id TEXT NOT NULL,
        attempt_id TEXT NOT NULL,
        printer_id TEXT NOT NULL,
        document_url TEXT NOT NULL,
        file_name TEXT NOT NULL,
        options TEXT NOT NULL,
        expires_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'PENDING',
        server_acknowledged INTEGER NOT NULL DEFAULT 0,
        result_json TEXT,
        error_message TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );
      CREATE INDEX IF NOT EXISTS idx_local_status ON local_commands(status);
    `);
    const columns = this.db.prepare(`PRAGMA table_info(local_commands)`).all();
    if (!columns.some((column) => column.name === "result_json")) {
      this.db.exec(`ALTER TABLE local_commands ADD COLUMN result_json TEXT`);
    }
    if (!columns.some((column) => column.name === "expires_at")) {
      this.db.exec(`ALTER TABLE local_commands ADD COLUMN expires_at TEXT NOT NULL DEFAULT ''`);
    }
    if (!columns.some((column) => column.name === "server_acknowledged")) {
      this.db.exec(`ALTER TABLE local_commands ADD COLUMN server_acknowledged INTEGER NOT NULL DEFAULT 0`);
    }
    const interrupted = this.db.prepare(`SELECT command_id, job_id, attempt_id FROM local_commands WHERE status = 'DISPATCHED_TO_SPOOLER'`).all();
    const markUncertain = this.db.prepare(`UPDATE local_commands
      SET status = 'REPORT_PENDING', result_json = ?, error_message = ?, document_url = '', file_name = '',
          printer_id = '', options = '{}', expires_at = '', updated_at = ?
      WHERE command_id = ? AND status = 'DISPATCHED_TO_SPOOLER'`);
    const now = (/* @__PURE__ */ new Date()).toISOString();
    for (const row of interrupted) {
      const errorMessage = "The agent restarted while this job was in spooler dispatch. Physical output is uncertain; operator reconciliation is required. The job was not retried.";
      const result = { attemptId: row.attempt_id, jobId: row.job_id, status: "OUTPUT_UNCERTAIN", errorMessage, timestamp: now };
      markUncertain.run(JSON.stringify(result), errorMessage, now, row.command_id);
    }
    this.db.prepare(`UPDATE local_commands
      SET document_url = '', file_name = '', printer_id = '', options = '{}', expires_at = ''
      WHERE status IN ('REPORT_PENDING', 'COMPLETED', 'OUTPUT_UNCERTAIN', 'FAILED')`).run();
  }
  enqueue(ticket) {
    const existing = this.db.prepare(`SELECT command_id FROM local_commands WHERE command_id = ?`).get(ticket.commandId);
    if (existing) return false;
    const now = (/* @__PURE__ */ new Date()).toISOString();
    this.db.prepare(`
      INSERT INTO local_commands (
        command_id, job_id, attempt_id, printer_id, document_url, file_name, options, expires_at, status, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'PENDING', ?, ?)
    `).run(
      ticket.commandId,
      ticket.jobId,
      ticket.attemptId,
      ticket.printerId,
      ticket.documentUrl,
      ticket.fileName,
      JSON.stringify(ticket.options),
      ticket.expiresAt,
      now,
      now
    );
    return true;
  }
  getNextPending() {
    const row = this.db.prepare(`SELECT * FROM local_commands WHERE status = 'PENDING' AND server_acknowledged = 1 ORDER BY created_at ASC LIMIT 1`).get();
    if (!row) return null;
    return this.mapRow(row);
  }
  /** Atomically claim the next acknowledged command before starting a spooler call.
   * This compare-and-set prevents two agent processes sharing the same queue DB
   * from selecting and physically printing the same pending command.
   */
  claimNextPending() {
    const row = this.db.prepare(`
      UPDATE local_commands
      SET status = 'DISPATCHED_TO_SPOOLER', error_message = NULL, updated_at = ?
      WHERE command_id = (
        SELECT command_id FROM local_commands
        WHERE status = 'PENDING' AND server_acknowledged = 1
        ORDER BY created_at ASC LIMIT 1
      )
        AND status = 'PENDING'
        AND server_acknowledged = 1
      RETURNING *
    `).get((/* @__PURE__ */ new Date()).toISOString());
    return row ? this.mapRow(row) : null;
  }
  getPendingAcknowledgements(limit = 50) {
    return this.db.prepare(
      `SELECT command_id, attempt_id FROM local_commands
       WHERE status = 'PENDING' AND server_acknowledged = 0
       ORDER BY created_at ASC LIMIT ?`
    ).all(limit).map((row) => ({ commandId: row.command_id, attemptId: row.attempt_id }));
  }
  markServerAcknowledged(commandId, attemptId) {
    const result = this.db.prepare(
      `UPDATE local_commands SET server_acknowledged = 1, updated_at = ?
       WHERE command_id = ? AND attempt_id = ? AND status = 'PENDING' AND server_acknowledged = 0`
    ).run((/* @__PURE__ */ new Date()).toISOString(), commandId, attemptId);
    return Number(result.changes) > 0;
  }
  updateStatus(commandId, status, error) {
    const now = (/* @__PURE__ */ new Date()).toISOString();
    const discardTicket = ["REPORT_PENDING", "COMPLETED", "OUTPUT_UNCERTAIN", "FAILED"].includes(status);
    this.db.prepare(`
      UPDATE local_commands SET status = ?, error_message = ?,
        document_url = CASE WHEN ? THEN '' ELSE document_url END,
        file_name = CASE WHEN ? THEN '' ELSE file_name END,
        printer_id = CASE WHEN ? THEN '' ELSE printer_id END,
        options = CASE WHEN ? THEN '{}' ELSE options END,
        expires_at = CASE WHEN ? THEN '' ELSE expires_at END,
        updated_at = ? WHERE command_id = ?
    `).run(
      status,
      error || null,
      discardTicket ? 1 : 0,
      discardTicket ? 1 : 0,
      discardTicket ? 1 : 0,
      discardTicket ? 1 : 0,
      discardTicket ? 1 : 0,
      now,
      commandId
    );
  }
  saveResult(commandId, result) {
    this.db.prepare(`UPDATE local_commands
      SET status = 'REPORT_PENDING', result_json = ?, document_url = '', file_name = '',
          printer_id = '', options = '{}', expires_at = '', updated_at = ? WHERE command_id = ?`).run(JSON.stringify(result), (/* @__PURE__ */ new Date()).toISOString(), commandId);
  }
  getPendingReports(limit = 50) {
    const rows = this.db.prepare(`SELECT * FROM local_commands WHERE status = 'REPORT_PENDING' ORDER BY updated_at ASC LIMIT ?`).all(limit);
    return rows.map(this.mapRow);
  }
  completeReport(commandId, result) {
    const status = result.status === "OUTPUT_UNCERTAIN" ? "OUTPUT_UNCERTAIN" : result.status === "FAILED" ? "FAILED" : "COMPLETED";
    this.db.prepare(`UPDATE local_commands
      SET status = ?, error_message = ?, result_json = NULL, document_url = '', file_name = '',
          printer_id = '', options = '{}', expires_at = '', updated_at = ? WHERE command_id = ?`).run(status, result.errorMessage || null, (/* @__PURE__ */ new Date()).toISOString(), commandId);
  }
  getQueueDepth() {
    const row = this.db.prepare(`SELECT COUNT(*) as count FROM local_commands WHERE status = 'PENDING'`).get();
    return row?.count || 0;
  }
  getRecent(limit = 20) {
    const rows = this.db.prepare(`SELECT * FROM local_commands ORDER BY created_at DESC LIMIT ?`).all(limit);
    return rows.map(this.mapRow);
  }
  close() {
    try {
      this.db.close();
    } catch {
    }
  }
  mapRow(r) {
    return {
      commandId: r.command_id,
      jobId: r.job_id,
      attemptId: r.attempt_id,
      printerId: r.printer_id,
      documentUrl: r.document_url,
      fileName: r.file_name,
      options: JSON.parse(r.options),
      expiresAt: r.expires_at || "",
      status: r.status,
      serverAcknowledged: Boolean(r.server_acknowledged),
      errorMessage: r.error_message || void 0,
      result: r.result_json ? JSON.parse(r.result_json) : void 0,
      createdAt: r.created_at,
      updatedAt: r.updated_at
    };
  }
};

// apps/agent/src/printer-discovery.ts
var import_node_child_process = require("node:child_process");
var import_node_util = require("node:util");

// apps/agent/src/print-commands.ts
function mapPaperNames(names) {
  const sizes = /* @__PURE__ */ new Set();
  for (const raw of names) {
    const name = String(raw).toLowerCase();
    if (/(^|[^a-z0-9])(iso_)?a4([^0-9]|$)/.test(name)) sizes.add("A4");
    if (/(^|[^a-z0-9])(iso_)?a3([^0-9]|$)/.test(name)) sizes.add("A3");
  }
  return [...sizes].sort();
}
function parseCupsQueues(lpstatPrinters, lpstatDefault) {
  const defaultMatch = /system default destination:\s*(\S+)/i.exec(lpstatDefault);
  const defaultName = defaultMatch ? defaultMatch[1] : "";
  const queues = [];
  for (const line of lpstatPrinters.split(/\r?\n/)) {
    const match = /^printer\s+(\S+)\s+(.*)$/i.exec(line.trim());
    if (!match) continue;
    const [, name, rest] = match;
    const isOnline = !/disabled/i.test(rest);
    queues.push({ name, isOnline, isDefault: name === defaultName });
  }
  return queues;
}
var CUPS_PRINTER_COLOR = 4;
var CUPS_PRINTER_DUPLEX = 16;
function parseCupsCapabilities(attributes, driverOptions) {
  let color = null;
  let duplex = null;
  const typeMatch = /(?:^|\s)printer-type=(\d+)/.exec(attributes);
  if (typeMatch) {
    const type2 = Number(typeMatch[1]);
    color = (type2 & CUPS_PRINTER_COLOR) !== 0;
    duplex = (type2 & CUPS_PRINTER_DUPLEX) !== 0;
  }
  const optionValues = (pattern) => {
    const line = driverOptions.split(/\r?\n/).find((entry) => pattern.test(entry));
    if (!line) return null;
    const values = line.slice(line.indexOf(":") + 1).trim().split(/\s+/).map((value) => value.replace(/^\*/, ""));
    return values.filter(Boolean);
  };
  if (color === null) {
    const colorModel = optionValues(/^(ColorModel|print-color-mode|ColorMode)\//i);
    if (colorModel) color = colorModel.some((value) => /rgb|cmy|color|colour/i.test(value) && !/^gray|^grey|^mono/i.test(value));
  }
  if (duplex === null) {
    const duplexValues = optionValues(/^(Duplex|sides)\//i);
    if (duplexValues) duplex = duplexValues.some((value) => /duplex(no)?tumble|two-sided/i.test(value));
  }
  const pageSizes = optionValues(/^(PageSize|media)\//i) || [];
  const makeMatch = /printer-make-and-model='([^']*)'|printer-make-and-model=(\S+)/.exec(attributes);
  return {
    color,
    duplex,
    paperSizes: mapPaperNames(pageSizes),
    makeAndModel: makeMatch ? makeMatch[1] ?? makeMatch[2] ?? null : null
  };
}
function parseWindowsCapabilities(capabilityDescriptions, paperNames) {
  const caps = Array.isArray(capabilityDescriptions) ? capabilityDescriptions.map(String) : [];
  const papers = Array.isArray(paperNames) ? paperNames.map(String) : [];
  return {
    color: caps.length ? caps.some((cap) => /^colou?r$/i.test(cap.trim())) : null,
    duplex: caps.length ? caps.some((cap) => /^duplex$/i.test(cap.trim())) : null,
    paperSizes: mapPaperNames(papers)
  };
}
function effectiveColorMode(options) {
  return options.colorMode === "bw" ? "bw" : "color";
}
function unsupportedPrintOptions(options) {
  const pagesPerSheet = options.pagesPerSheet ?? 1;
  if (options.duplexMode === "duplex_manual") return "Manual duplex needs an operator at the printer; no document was submitted.";
  if (pagesPerSheet !== 1) return "Multiple pages per sheet is not supported by this agent; no document was submitted.";
  if (!["A4", "A3", "PLAIN"].includes(String(options.paperSize))) return "This agent cannot verify the requested paper size/type; no document was submitted.";
  const copies = Number(options.copies);
  if (!Number.isInteger(copies) || copies < 1 || copies > 99) return "Invalid copy count; no document was submitted.";
  if (options.pageRange && options.pageRange !== "All" && !/^\s*\d+(\s*-\s*\d+)?(\s*,\s*\d+(\s*-\s*\d+)?)*\s*$/.test(options.pageRange)) {
    return "Invalid page range; no document was submitted.";
  }
  return null;
}
function buildSumatraSettings(options) {
  const parts = [`${Number(options.copies)}x`, effectiveColorMode(options) === "bw" ? "monochrome" : "color"];
  if (options.pageRange && options.pageRange !== "All") parts.push(options.pageRange.replace(/\s+/g, ""));
  if (options.fitMode === "fit") parts.push("fit");
  if (options.orientation === "portrait" || options.orientation === "landscape") parts.push(options.orientation);
  if (options.duplexMode === "duplex_auto") parts.push(options.orientation === "landscape" ? "duplexshort" : "duplexlong");
  else parts.push("simplex");
  parts.push(options.collation ? "collate" : "nocollate");
  if (options.paperSize === "A4" || options.paperSize === "A3") parts.push(`paper=${options.paperSize}`);
  return parts.join(",");
}
function buildLpArgs(queueName, filePath, options, title) {
  const color = effectiveColorMode(options);
  const args = ["-d", queueName, "-n", String(Number(options.copies)), "-t", title.replace(/[^\w .()-]/g, "_").slice(0, 120) || "Inklly print"];
  const opt = (value) => {
    args.push("-o", value);
  };
  opt(`print-color-mode=${color === "bw" ? "monochrome" : "color"}`);
  if (color === "bw") opt("ColorModel=Gray");
  if (options.duplexMode === "duplex_auto") opt(options.orientation === "landscape" ? "sides=two-sided-short-edge" : "sides=two-sided-long-edge");
  else opt("sides=one-sided");
  if (options.paperSize === "A4" || options.paperSize === "A3") opt(`media=${options.paperSize}`);
  if (options.pageRange && options.pageRange !== "All") opt(`page-ranges=${options.pageRange.replace(/\s+/g, "")}`);
  if (options.orientation === "landscape") opt("orientation-requested=4");
  else if (options.orientation === "portrait") opt("orientation-requested=3");
  if (options.fitMode === "fit") opt("fit-to-page");
  opt(`collate=${options.collation ? "true" : "false"}`);
  args.push("--", filePath);
  return args;
}
function parseLpJobId(stdout) {
  const match = /request id is \S+-(\d+)/i.exec(stdout);
  return match ? Number(match[1]) : void 0;
}

// apps/agent/src/printer-discovery.ts
var execFileAsync = (0, import_node_util.promisify)(import_node_child_process.execFile);
var run = async (file, args, timeout = 5e3) => {
  const { stdout } = await execFileAsync(file, args, { encoding: "utf-8", timeout, windowsHide: true, maxBuffer: 4 * 1024 * 1024 });
  return String(stdout);
};
var PrinterDiscoveryService = class {
  static async discoverPrinters() {
    try {
      if (process.platform === "win32") return await this.discoverWindows();
      if (process.platform === "darwin" || process.platform === "linux" || process.platform === "freebsd") return await this.discoverCups();
    } catch (error) {
      console.warn("[Inklly Agent] Printer discovery failed:", error instanceof Error ? error.message : error);
    }
    return [];
  }
  static async discoverWindows() {
    const script = "Get-CimInstance Win32_Printer | Select-Object Name,DriverName,PrinterStatus,DetectedErrorState,WorkOffline,Default,CapabilityDescriptions,PrinterPaperNames | ConvertTo-Json -Depth 3";
    const stdout = await run("powershell", ["-NoProfile", "-NonInteractive", "-Command", script], 8e3);
    if (!stdout.trim()) return [];
    const parsed = JSON.parse(stdout.trim());
    const list = Array.isArray(parsed) ? parsed : [parsed];
    return list.filter((p) => p && typeof p.Name === "string").map((p) => {
      const capabilities = parseWindowsCapabilities(p.CapabilityDescriptions, p.PrinterPaperNames);
      return {
        name: p.Name,
        driverName: p.DriverName || "Unknown driver",
        isOnline: !Boolean(p.WorkOffline) && ![6, 7].includes(Number(p.PrinterStatus)) && ![3, 4, 5, 6].includes(Number(p.DetectedErrorState)),
        isDefault: Boolean(p.Default),
        supportsColor: capabilities.color === true,
        supportsDuplex: capabilities.duplex === true,
        trays: [],
        capabilities
      };
    });
  }
  static async discoverCups() {
    let printersOut = "";
    try {
      printersOut = await run("lpstat", ["-p"]);
    } catch (error) {
      printersOut = String(error?.stdout || "");
    }
    let defaultOut = "";
    try {
      defaultOut = await run("lpstat", ["-d"]);
    } catch (error) {
      defaultOut = String(error?.stdout || "");
    }
    const queues = parseCupsQueues(printersOut, defaultOut);
    const discovered = [];
    for (const queue of queues) {
      let attributes = "";
      let driverOptions = "";
      try {
        attributes = await run("lpoptions", ["-p", queue.name]);
      } catch {
      }
      try {
        driverOptions = await run("lpoptions", ["-p", queue.name, "-l"]);
      } catch {
      }
      const { makeAndModel, ...capabilities } = parseCupsCapabilities(attributes, driverOptions);
      discovered.push({
        name: queue.name,
        driverName: makeAndModel || "CUPS queue",
        isOnline: queue.isOnline,
        isDefault: queue.isDefault,
        supportsColor: capabilities.color === true,
        supportsDuplex: capabilities.duplex === true,
        trays: [],
        capabilities
      });
    }
    return discovered;
  }
  static async checkPrinterHealth(printerName) {
    if (process.platform === "win32") {
      try {
        const escapedName = printerName.replace(/'/g, "''");
        const script = `$ErrorActionPreference='Stop'; $p=Get-CimInstance Win32_Printer | Where-Object {$_.Name -eq '${escapedName}'} | Select-Object -First 1; if($null -eq $p){[pscustomobject]@{exists=$false;workOffline=$true;printerStatus=7;detectedErrorState=9;printStatus='NotAvailable'}|ConvertTo-Json -Compress;exit}; $gp=$null; try{$gp=Get-Printer -Name '${escapedName}' -ErrorAction Stop}catch{}; [pscustomobject]@{exists=$true;workOffline=[bool]$p.WorkOffline;printerStatus=[int]$p.PrinterStatus;detectedErrorState=[int]$p.DetectedErrorState;printStatus=if($gp){[string]$gp.PrinterStatus}else{''}}|ConvertTo-Json -Compress`;
        const stdout = await run("powershell", ["-NoProfile", "-NonInteractive", "-Command", script], 4e3);
        const row = JSON.parse(stdout.trim());
        const status = String(row.printStatus || "");
        const paperFault = [3, 4, 5, 6].includes(Number(row.detectedErrorState)) || /paper\s*out|no\s*paper/i.test(status);
        const jamFault = [4, 6, 7, 8, 9, 10, 11].includes(Number(row.detectedErrorState)) || /jam|door\s*open/i.test(status);
        const hardFault = !row.exists || row.workOffline || [6, 7].includes(Number(row.printerStatus)) || jamFault || paperFault;
        return { ready: !hardFault, status: status || `PrinterStatus=${row.printerStatus}`, paperFault, jamFault };
      } catch {
        return { ready: false, status: "Printer health could not be verified", paperFault: false, jamFault: false };
      }
    }
    if (process.platform === "darwin" || process.platform === "linux" || process.platform === "freebsd") {
      try {
        const out = await run("lpstat", ["-p", printerName]);
        const queue = parseCupsQueues(out, "").find((entry) => entry.name === printerName);
        const paperFault = /media-empty|paper out|out of paper/i.test(out);
        const jamFault = /jam|door-open|cover open/i.test(out);
        return { ready: Boolean(queue?.isOnline) && !paperFault && !jamFault, status: out.trim().slice(0, 200), paperFault, jamFault };
      } catch {
        return { ready: false, status: "Printer queue not found", paperFault: false, jamFault: false };
      }
    }
    return { ready: false, status: "Printer health checks are unavailable on this operating system", paperFault: false, jamFault: false };
  }
};

// apps/agent/src/spooler-executor.ts
var fs3 = __toESM(require("node:fs"));
var path3 = __toESM(require("node:path"));
var os = __toESM(require("node:os"));
var import_node_child_process2 = require("node:child_process");
var import_node_util2 = require("node:util");
var execFileAsync2 = (0, import_node_util2.promisify)(import_node_child_process2.execFile);
var MAX_PRINT_FILE_BYTES = 35 * 1024 * 1024;
var ALLOWED_DOWNLOAD_TYPES = /* @__PURE__ */ new Set(["application/pdf", "image/jpeg", "image/png", "image/tiff"]);
async function downloadTicketDocument(documentUrl, serverUrl, headers = {}) {
  const expectedBase = new URL(serverUrl);
  const target = new URL(documentUrl);
  const expectedPath = `${expectedBase.pathname.replace(/\/$/, "")}/agent/files/`;
  const fileId = target.pathname.startsWith(expectedPath) ? target.pathname.slice(expectedPath.length) : "";
  if (target.origin !== expectedBase.origin || target.username || target.password || target.search || target.hash || target.pathname !== `${expectedPath}${fileId}` || !/^[A-Za-z0-9_-]{1,128}$/.test(fileId) || target.protocol !== "https:" && !["localhost", "127.0.0.1", "[::1]"].includes(target.hostname)) {
    throw new Error("Print document URL does not match the paired Inklly server.");
  }
  const response = await fetch(target, { headers, redirect: "manual", signal: AbortSignal.timeout(3e4) });
  if (response.status >= 300 && response.status < 400) throw new Error("Print document server redirects are not allowed.");
  if (!response.ok) throw new Error(`Print document download failed (HTTP ${response.status}).`);
  const length = Number(response.headers.get("content-length"));
  if (Number.isFinite(length) && length > MAX_PRINT_FILE_BYTES) throw new Error("Print document exceeds the 35 MiB download limit.");
  const contentType = (response.headers.get("content-type") || "").split(";", 1)[0].trim().toLowerCase();
  if (!ALLOWED_DOWNLOAD_TYPES.has(contentType)) throw new Error("Print document has an unsupported content type.");
  if (!response.body) throw new Error("Print document response is empty.");
  const chunks = [];
  let total = 0;
  const reader = response.body.getReader();
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > MAX_PRINT_FILE_BYTES) {
        await reader.cancel();
        throw new Error("Print document exceeds the 35 MiB download limit.");
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  const body = Buffer.concat(chunks, total);
  const isPdf = body.subarray(0, 5).toString("ascii") === "%PDF-";
  const isJpeg = body[0] === 255 && body[1] === 216 && body[2] === 255;
  const isPng = body.subarray(0, 8).equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]));
  const isTiff = body.subarray(0, 4).toString("ascii") === "II*\\0" || body.subarray(0, 4).toString("ascii") === "MM\\0*";
  if (!body.length || !(contentType === "application/pdf" && isPdf || contentType === "image/jpeg" && isJpeg || contentType === "image/png" && isPng || contentType === "image/tiff" && isTiff)) {
    throw new Error("Print document content does not match its declared type.");
  }
  const tempDir = await fs3.promises.mkdtemp(path3.join(os.tmpdir(), "inklly-print-"));
  const extension = contentType === "application/pdf" ? ".pdf" : contentType === "image/jpeg" ? ".jpg" : contentType === "image/png" ? ".png" : ".tif";
  const filePath = path3.join(tempDir, `document${extension}`);
  try {
    await fs3.promises.writeFile(filePath, body, { flag: "wx", mode: 384 });
    return filePath;
  } catch (error) {
    await fs3.promises.rm(tempDir, { recursive: true, force: true });
    throw error;
  }
}
var SpoolerExecutor = class {
  static async executeTicket(ticket, options) {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    if (options?.simulateFailure === "PAPER_JAM_UNCERTAIN") {
      return {
        attemptId: ticket.attemptId,
        jobId: ticket.jobId,
        status: "OUTPUT_UNCERTAIN",
        errorMessage: "Hardware alert: Paper jam reported during duplex feed. Physical sheets uncertain.",
        timestamp
      };
    }
    if (options?.simulateFailure === "TIMEOUT") {
      return {
        attemptId: ticket.attemptId,
        jobId: ticket.jobId,
        status: "OUTPUT_UNCERTAIN",
        errorMessage: "Spooler connection timed out while sending raw PCL stream. Verification required.",
        timestamp
      };
    }
    if (options?.simulateFailure === "SPOOLER_CRASH") {
      return {
        attemptId: ticket.attemptId,
        jobId: ticket.jobId,
        status: "FAILED",
        errorMessage: "Print spooler subsystem RPC failed.",
        timestamp
      };
    }
    if (process.env.INKLLY_ENABLE_PHYSICAL_PRINTING !== "true") {
      return {
        attemptId: ticket.attemptId,
        jobId: ticket.jobId,
        status: "FAILED",
        errorMessage: "Physical printing is disabled for this pilot; no document was downloaded or submitted.",
        timestamp
      };
    }
    const supported = process.platform === "win32" || process.platform === "darwin" || process.platform === "linux" || process.platform === "freebsd";
    if (!supported) {
      return {
        attemptId: ticket.attemptId,
        jobId: ticket.jobId,
        status: "FAILED",
        errorMessage: `Printing is not supported on ${process.platform}; no print was submitted.`,
        timestamp
      };
    }
    if (process.env.NODE_ENV === "test" && !options?.allowSpoolInTests) {
      return { attemptId: ticket.attemptId, jobId: ticket.jobId, status: "FAILED", errorMessage: "Spooling is disabled in tests; no print was submitted.", timestamp };
    }
    try {
      return await this.spoolToSystemPrinter(ticket, options);
    } catch (err) {
      console.error("[SpoolerExecutor] Physical spool error:", err);
      return {
        attemptId: ticket.attemptId,
        jobId: ticket.jobId,
        status: "OUTPUT_UNCERTAIN",
        errorMessage: `Printer spooler alert: ${err?.message || "driver error"}. Check the printer before retrying.`,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      };
    }
  }
  static async spoolToSystemPrinter(ticket, options) {
    const timestamp = (/* @__PURE__ */ new Date()).toISOString();
    const fail = (errorMessage) => ({ attemptId: ticket.attemptId, jobId: ticket.jobId, status: "FAILED", errorMessage, timestamp: (/* @__PURE__ */ new Date()).toISOString() });
    const printOptions = ticket.options;
    const unsupported = unsupportedPrintOptions(printOptions);
    if (unsupported) return fail(unsupported);
    const requestedPrinter = options?.targetPrinterOverride || ticket.printerId;
    let targetPrinter = "";
    try {
      const detected = await PrinterDiscoveryService.discoverPrinters();
      const match = detected.find((p) => p.name === requestedPrinter);
      if (match?.isOnline) targetPrinter = match.name;
    } catch {
    }
    if (!targetPrinter) return fail("The assigned printer queue is not present and online on this computer; no document was submitted.");
    const windows = process.platform === "win32";
    let sumatraExe = "";
    if (windows) {
      const possibleBinPaths = [
        path3.join(__dirname, "..", "bin", "SumatraPDF.exe"),
        path3.join(process.cwd(), "bin", "SumatraPDF.exe"),
        path3.join(process.cwd(), "apps", "agent", "bin", "SumatraPDF.exe")
      ];
      sumatraExe = possibleBinPaths.find((p) => fs3.existsSync(p)) || "";
      if (!sumatraExe) return fail("SumatraPDF.exe is not installed with the agent; no print was submitted.");
    }
    if (!ticket.documentUrl || !options?.downloadServerUrl) return fail("The customer document is unavailable; no substitute document was printed.");
    let filePath;
    try {
      filePath = await downloadTicketDocument(ticket.documentUrl, options.downloadServerUrl, options.downloadHeaders);
    } catch (err) {
      return fail(`The customer document could not be validated or downloaded; no print was submitted. ${err?.message || "Download failed."}`);
    }
    try {
      let driverJobId;
      if (windows) {
        console.log(`[Inklly Spooler] Sending job ${ticket.jobId} to "${targetPrinter}" via SumatraPDF`);
        await execFileAsync2(sumatraExe, ["-print-to", targetPrinter, "-silent", "-print-settings", buildSumatraSettings(printOptions), filePath], { timeout: 12e4, windowsHide: true });
      } else {
        console.log(`[Inklly Spooler] Sending job ${ticket.jobId} to CUPS queue "${targetPrinter}"`);
        const { stdout } = await execFileAsync2("lp", buildLpArgs(targetPrinter, filePath, printOptions, ticket.fileName || "Inklly print"), { timeout: 6e4 });
        driverJobId = parseLpJobId(String(stdout));
      }
      return { attemptId: ticket.attemptId, jobId: ticket.jobId, status: "SUBMITTED_TO_SPOOLER", driverJobId, timestamp };
    } finally {
      const tempDir = path3.dirname(filePath);
      setTimeout(() => {
        void fs3.promises.rm(tempDir, { recursive: true, force: true }).catch(() => void 0);
      }, 6e4).unref();
    }
  }
};

// apps/agent/src/agent-daemon.ts
var AgentDaemon = class {
  configManager;
  queue;
  server = null;
  isRunning = false;
  printers = [];
  heartbeatInterval = null;
  pollInterval = null;
  workerInterval = null;
  discoveryInterval = null;
  discovering = false;
  workerPromise = null;
  constructor(configManager, queue) {
    this.configManager = configManager || new ConfigManager();
    const config = this.configManager.get();
    this.queue = queue || new LocalOfflineQueue(config.offlineQueuePath);
  }
  async start() {
    this.isRunning = true;
    this.printers = await PrinterDiscoveryService.discoverPrinters();
    const config = this.configManager.get();
    this.server = http.createServer((req, res) => this.handleLocalRequest(req, res));
    await new Promise((resolve, reject) => {
      this.server.listen(config.localPort, "127.0.0.1", () => {
        console.log(`[Inklly Agent] Local HTTP server listening on http://127.0.0.1:${config.localPort}`);
        resolve();
      });
      this.server.on("error", (err) => {
        if (err.code === "EADDRINUSE") {
          console.warn(`[Inklly Agent] Port ${config.localPort} in use. Continuing without local diagnostic server.`);
          resolve();
        } else {
          reject(err);
        }
      });
    });
    if (!config.isPaired && config.pairingCode) {
      await this.enrollWithServer();
    }
    if (!this.configManager.get().isPaired && process.stdin.isTTY && process.env.INKLLY_NO_PROMPT !== "true") {
      await this.promptForPairing();
    }
    this.printStatus();
    this.heartbeatInterval = setInterval(() => this.sendHeartbeat(), config.heartbeatIntervalMs);
    this.pollInterval = setInterval(() => this.pollServerCommands(), config.pollIntervalMs);
    this.workerInterval = setInterval(() => {
      this.runWorkerCycle();
    }, 2e3);
    this.discoveryInterval = setInterval(() => void this.refreshPrinters(), Number(process.env.INKLLY_PRINTER_DISCOVERY_MS) || 6e4);
    this.sendHeartbeat();
    this.pollServerCommands();
  }
  async stop() {
    this.isRunning = false;
    if (this.heartbeatInterval) clearInterval(this.heartbeatInterval);
    if (this.pollInterval) clearInterval(this.pollInterval);
    if (this.workerInterval) clearInterval(this.workerInterval);
    if (this.discoveryInterval) clearInterval(this.discoveryInterval);
    if (this.workerPromise) await this.workerPromise;
    if (this.server) {
      await new Promise((resolve) => this.server.close(() => resolve()));
      this.server = null;
    }
    this.queue.close();
    console.log("[Inklly Agent] Daemon stopped cleanly.");
  }
  async refreshPrinters() {
    if (this.discovering || !this.isRunning) return;
    this.discovering = true;
    try {
      const before = JSON.stringify(this.printers.map((p) => [p.name, p.isOnline, p.isDefault]));
      this.printers = await PrinterDiscoveryService.discoverPrinters();
      if (JSON.stringify(this.printers.map((p) => [p.name, p.isOnline, p.isDefault])) !== before) {
        console.log(`[Inklly Agent] Printer list changed: ${this.printers.map((p) => `${p.name}${p.isOnline ? "" : " (offline)"}`).join(", ") || "none"}`);
        await this.sendHeartbeat();
      }
    } finally {
      this.discovering = false;
    }
  }
  runWorkerCycle() {
    if (!this.isRunning || this.workerPromise) return;
    this.workerPromise = (async () => {
      await this.processPendingReports();
      await this.processPendingAcknowledgements();
      if (this.isRunning) await this.processNextQueueItem();
    })().catch((err) => {
      console.error("[Inklly Agent] Queue worker cycle failed; the command will not be blindly retried:", err);
    }).finally(() => {
      this.workerPromise = null;
    });
  }
  /** Asks for the pairing code shown in Inklly → Printers until pairing succeeds. */
  async promptForPairing() {
    const readline = await import("node:readline/promises");
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    try {
      console.log("");
      console.log("  To connect this computer to your shop:");
      console.log("  1. On your Inklly dashboard open  Business Setup \u2192 Printers");
      console.log("  2. Click  \u201CCreate pairing code\u201D");
      console.log("  3. Type or paste the code here (it looks like INK-ABCD-EFGH-JKLM-NPQR)");
      console.log("");
      for (let attempt = 0; attempt < 10 && this.isRunning; attempt++) {
        const code = (await rl.question("  Pairing code: ")).trim();
        if (!code) continue;
        this.configManager.update({ pairingCode: code });
        if (await this.enrollWithServer()) return;
        console.log("  \u2717 " + (this.lastEnrollError || "That code did not work. Create a new code and try again."));
      }
    } finally {
      rl.close();
    }
  }
  lastEnrollError = "";
  /** A plain-language summary shopkeepers can read in the app window. */
  printStatus() {
    const config = this.configManager.get();
    const printing = process.env.INKLLY_ENABLE_PHYSICAL_PRINTING === "true";
    console.log("");
    console.log("  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
    console.log(config.isPaired ? `  \u2713 Connected to shop: ${config.shopCode || config.shopId}` : "  \u2717 Not connected to a shop yet (restart and enter a pairing code)");
    console.log(printing ? "  \u2713 Printing is ON" : "  ! Printing is OFF (set INKLLY_ENABLE_PHYSICAL_PRINTING=true)");
    if (this.printers.length) {
      console.log("  Printers found on this computer:");
      for (const printer of this.printers) {
        const caps = printer.capabilities;
        const traits = [caps.color ? "colour" : caps.color === false ? "B&W" : null, caps.duplex ? "both sides" : null, caps.paperSizes.join("/") || null].filter(Boolean).join(", ");
        console.log(`   \u2022 ${printer.name}${printer.isOnline ? "" : " (offline)"}${traits ? ` \u2014 ${traits}` : ""}`);
      }
    } else {
      console.log("  ! No printers found. Install your printer on this computer first, then restart Inklly.");
    }
    console.log("  Keep this window open while the shop is open. Orders print when staff press Print.");
    console.log("  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500");
    console.log("");
  }
  async enrollWithServer(shopId, _secretKey) {
    const config = this.configManager.get();
    const targetShopId = shopId || config.shopId;
    if (!config.pairingCode) return false;
    try {
      const res = await fetch(`${config.serverUrl}/agent/enroll`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...targetShopId ? { shopId: targetShopId } : {},
          pairingCode: config.pairingCode,
          hostname: (process.env.COMPUTERNAME || os2.hostname() || "print-computer").slice(0, 100),
          osPlatform: process.platform,
          osVersion: `${os2.type()} ${os2.release()}`.slice(0, 100),
          agentVersion: "1.0.0"
        })
      });
      if (res.ok) {
        const body = await res.json();
        this.configManager.update({
          shopId: body.shopId,
          shopCode: body.shopCode,
          agentId: body.agentId,
          secretKey: body.agentSecret,
          pairingCode: void 0,
          isPaired: true
        });
        delete process.env.INKLLY_PAIRING_CODE;
        console.log(`  \u2713 Paired with ${body.shopName || body.shopCode}.`);
        await this.sendHeartbeat();
        return true;
      }
      const failure = await res.json().catch(() => ({}));
      this.lastEnrollError = failure.error || `The server refused the code (HTTP ${res.status}).`;
      this.configManager.update({ pairingCode: void 0 });
    } catch (err) {
      this.lastEnrollError = `Could not reach Inklly (${err.message}). Check the internet connection.`;
      console.warn("[Inklly Agent] Enrollment pending server availability:", err.message);
    }
    return false;
  }
  async sendHeartbeat() {
    const config = this.configManager.get();
    if (!config.agentId || !config.shopId || !config.secretKey) return;
    try {
      await fetch(`${config.serverUrl}/agent/heartbeat`, {
        method: "POST",
        headers: this.agentHeaders(config),
        signal: AbortSignal.timeout(1e4),
        body: JSON.stringify({
          agentId: config.agentId,
          shopId: config.shopId,
          status: "ONLINE",
          activePrintersCount: this.printers.filter((p) => p.isOnline).length,
          printers: this.printers.map((printer) => ({
            name: printer.name,
            driverName: printer.driverName,
            isOnline: printer.isOnline,
            isDefault: printer.isDefault,
            capabilities: printer.capabilities
          })),
          localQueueDepth: this.queue.getQueueDepth(),
          sqliteCacheHealthy: true,
          physicalPrintingEnabled: process.env.INKLLY_ENABLE_PHYSICAL_PRINTING === "true"
        })
      });
    } catch {
    }
  }
  async pollServerCommands() {
    const config = this.configManager.get();
    if (!config.agentId || !config.secretKey) return 0;
    try {
      const res = await fetch(`${config.serverUrl}/agent/poll-commands`, {
        headers: this.agentHeaders(config),
        signal: AbortSignal.timeout(1e4)
      });
      if (!res.ok || !this.isRunning) return 0;
      const tickets = await res.json();
      let enqueued = 0;
      for (const ticket of tickets) {
        if (!this.isRunning) break;
        if (this.queue.enqueue(ticket)) enqueued++;
        await this.acknowledgeTicket(ticket.commandId, ticket.attemptId, config);
      }
      return enqueued;
    } catch {
      return 0;
    }
  }
  agentHeaders(config) {
    return { "Content-Type": "application/json", "X-Agent-Id": config.agentId || "", Authorization: `Bearer ${config.secretKey || ""}` };
  }
  async acknowledgeTicket(commandId, attemptId, config) {
    try {
      const response = await fetch(`${config.serverUrl}/agent/acknowledge-command`, {
        method: "POST",
        headers: this.agentHeaders(config),
        signal: AbortSignal.timeout(1e4),
        body: JSON.stringify({ commandId, attemptId })
      });
      if (!response.ok) return false;
      return this.queue.markServerAcknowledged(commandId, attemptId);
    } catch {
      return false;
    }
  }
  async processPendingAcknowledgements() {
    const config = this.configManager.get();
    if (!config.agentId || !config.secretKey) return;
    for (const pending of this.queue.getPendingAcknowledgements()) {
      await this.acknowledgeTicket(pending.commandId, pending.attemptId, config);
    }
  }
  async processNextQueueItem() {
    const item = this.queue.claimNextPending();
    if (!item) return null;
    const ticket = {
      commandId: item.commandId,
      jobId: item.jobId,
      attemptId: item.attemptId,
      shopId: this.configManager.get().shopId,
      printerId: item.printerId,
      documentUrl: item.documentUrl,
      fileName: item.fileName,
      options: item.options,
      expiresAt: item.expiresAt,
      correlationId: `corr-${item.jobId}`
    };
    const config = this.configManager.get();
    const expiry = Date.parse(item.expiresAt);
    const result = !Number.isFinite(expiry) || expiry <= Date.now() ? {
      attemptId: item.attemptId,
      jobId: item.jobId,
      status: "FAILED",
      errorMessage: "The server print ticket expired before local execution; no print was submitted.",
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    } : await SpoolerExecutor.executeTicket(ticket, {
      downloadServerUrl: config.serverUrl,
      downloadHeaders: this.agentHeaders(config)
    }).catch((err) => ({
      attemptId: item.attemptId,
      jobId: item.jobId,
      status: "OUTPUT_UNCERTAIN",
      errorMessage: `The print worker failed unexpectedly after dispatch began. Inspect the printer before retrying. ${err instanceof Error ? err.message : "Unknown execution error"}`,
      timestamp: (/* @__PURE__ */ new Date()).toISOString()
    }));
    this.queue.saveResult(item.commandId, result);
    await this.processPendingReports();
    return result;
  }
  async processPendingReports() {
    for (const item of this.queue.getPendingReports()) {
      if (item.result && await this.reportResultToServer(item.result)) {
        this.queue.completeReport(item.commandId, item.result);
      }
    }
  }
  async reportResultToServer(result) {
    const config = this.configManager.get();
    try {
      const response = await fetch(`${config.serverUrl}/agent/command-result`, {
        method: "POST",
        headers: this.agentHeaders(config),
        signal: AbortSignal.timeout(1e4),
        body: JSON.stringify(result)
      });
      return response.ok;
    } catch (err) {
      console.warn("[Inklly Agent] Failed to report spooler result back to server:", err.message);
      return false;
    }
  }
  handleLocalRequest(req, res) {
    const config = this.configManager.get();
    const host = (req.headers.host || "").toLowerCase();
    const allowedHosts = /* @__PURE__ */ new Set([
      `127.0.0.1:${config.localPort}`,
      `localhost:${config.localPort}`,
      `[::1]:${config.localPort}`
    ]);
    if (!allowedHosts.has(host)) {
      res.writeHead(403, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Local agent requests must use a loopback host." }));
      return;
    }
    const allowedOrigins = new Set((process.env.INKLLY_PORTAL_ORIGINS || "http://localhost:3000,http://127.0.0.1:3000,https://inklly.vercel.app").split(",").map((origin2) => origin2.trim()).filter(Boolean));
    const origin = req.headers.origin;
    if (origin && !allowedOrigins.has(origin)) {
      res.writeHead(403, { "Content-Type": "application/json", Vary: "Origin" });
      res.end(JSON.stringify({ error: "Origin is not allowed to access local agent diagnostics." }));
      return;
    }
    if (origin && allowedOrigins.has(origin)) res.setHeader("Access-Control-Allow-Origin", origin);
    res.setHeader("Vary", "Origin");
    res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
    if (req.method === "OPTIONS") {
      if (!origin) {
        res.writeHead(403);
        res.end();
        return;
      }
      res.writeHead(204);
      res.end();
      return;
    }
    if (req.method !== "GET") {
      res.writeHead(origin && !allowedOrigins.has(origin) ? 403 : 410, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ error: "Local agent endpoints are read-only. Use authenticated server pairing and dispatch." }));
      return;
    }
    if ((req.url === "/status" || req.url === "/health") && req.method === "GET") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(
        JSON.stringify({
          status: req.url === "/health" ? "OK" : "RUNNING",
          agentStatus: "RUNNING",
          version: "1.0.0",
          isPaired: config.isPaired,
          uptimeSec: Math.floor(process.uptime()),
          physicalPrintingEnabled: process.env.INKLLY_ENABLE_PHYSICAL_PRINTING === "true"
        })
      );
      return;
    }
    res.writeHead(404, { "Content-Type": "application/json" });
    res.end(JSON.stringify({ error: "Endpoint not found" }));
  }
};

// apps/agent/src/index.ts
async function main() {
  console.log("\u{1F5A8}\uFE0F  [Inklly Agent] Initializing desktop edge print daemon...");
  const daemon = new AgentDaemon();
  await daemon.start();
  process.on("SIGINT", () => {
    console.log("\n[Inklly Agent] Shutting down...");
    void daemon.stop().then(() => process.exit(0));
  });
  process.on("SIGTERM", () => {
    void daemon.stop().then(() => process.exit(0));
  });
}
if (require.main === module) {
  main().catch((err) => {
    console.error("[Inklly Agent Fatal Error]:", err);
    process.exit(1);
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  AgentDaemon,
  ConfigManager,
  LocalOfflineQueue,
  PrinterDiscoveryService,
  SpoolerExecutor,
  downloadTicketDocument
});
