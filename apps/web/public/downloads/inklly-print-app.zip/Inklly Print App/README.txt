Inklly Print App 1.0.0
=====================================

Install this on the computer your printers are connected to. It sends orders
from your Inklly Counter to the printer you choose — only when staff press Print.

BEFORE YOU START
  * Install your printer(s) on this computer as usual and print a test page.
  * Unzip this folder somewhere you can write to, e.g. Documents\Inklly Print App.

WINDOWS
  1. Double-click "Start Inklly (Windows).bat".
     The first time, it installs Node.js (free) if needed — then run it again.
  2. In your Inklly dashboard open Business Setup > Printers and click
     "Create pairing code". Type or paste the code into the Inklly window.
  3. Keep the window open (you can minimise it). Your printers now appear in
     Inklly with their colour / double-sided / paper sizes.
  Optional: double-click "Start Inklly with Windows.bat" so it opens at sign-in.

MAC
  1. Right-click "Start Inklly (Mac).command" > Open (the first time macOS asks
     you to confirm). Install Node.js from nodejs.org if asked, then open it again.
  2. Enter the pairing code from Business Setup > Printers.

LINUX
  Run ./start-inklly-linux.sh in a terminal and enter the pairing code.

TROUBLESHOOTING
  * "No printers found": install the printer on this computer, then restart.
  * Printer shows offline in Inklly: check it is switched on and has paper.
  * To connect to a different shop, delete the "data" folder and start again.

Printing on Windows uses SumatraPDF 3.4.6 (bin\SumatraPDF.exe), free software
under the GNU GPL v3 — source: https://github.com/sumatrapdfreader/sumatrapdf
