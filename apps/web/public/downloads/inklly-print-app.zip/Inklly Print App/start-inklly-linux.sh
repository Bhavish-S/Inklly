#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo "  Inklly Print App 1.0.0"
echo "  ------------------------------------------------"
if ! command -v node >/dev/null 2>&1 || ! node -e "require('node:sqlite')" >/dev/null 2>&1; then
  echo "  Inklly needs a recent Node.js (free)."
  echo "  Install Node.js 22 or newer (for example: sudo apt install nodejs, or from https://nodejs.org), then run this again."
  read -r -p "  Press Enter to close." _
  exit 1
fi
export INKLLY_ENABLE_PHYSICAL_PRINTING=true
export INKLLY_SERVER_URL=https://inklly.onrender.com/api/v1
node inklly-print-app.cjs
