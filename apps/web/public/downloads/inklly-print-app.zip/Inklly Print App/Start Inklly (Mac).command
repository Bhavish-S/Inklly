#!/bin/bash
cd "$(dirname "$0")"
echo ""
echo "  Inklly Print App 1.0.0"
echo "  ------------------------------------------------"
if ! command -v node >/dev/null 2>&1 || ! node -e "require('node:sqlite')" >/dev/null 2>&1; then
  echo "  Inklly needs a recent Node.js (free)."
  if command -v brew >/dev/null 2>&1; then
    echo "  Installing it with Homebrew..."; brew install node && exec "$0"
  fi
  echo "  Download the macOS installer for Node.js LTS from https://nodejs.org, install it, then open this file again."
  open "https://nodejs.org/en/download"
  read -r -p "  Press Enter to close." _
  exit 1
fi
export INKLLY_ENABLE_PHYSICAL_PRINTING=true
export INKLLY_SERVER_URL=https://inklly.onrender.com/api/v1
node inklly-print-app.cjs
